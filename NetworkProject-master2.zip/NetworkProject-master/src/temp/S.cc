#include <unistd.h>
#include <iostream>
#include <vector>
#include <ctime>
#include <igraph.h>
#include <string>
#include "runner_manager.h"
#include "runner.h"
//#incnlude "step_test.h"
#include "constant.h"
#include "parameter.h"
#include "CJsonObject.hpp"
#include "process.h"


int main(){
    std::string strValue ="{\"responseCode\":0,\"responseMsg\":\"查询成功\"}";
    neb::CJsonObject in_json(strValue);
    in_json.AddEmptySubArray("result");
	std::cout<<in_json.ToString()<<std::endl;
	for(int i =0;i<20;i++){
		std::string id = std::to_string(i);
		std::string str = "{\"userId\":\"";
		str.append(id);
		str.append("\",\"quaranTine\": 0,\"infected\":1,\"edge\":[]}");
		in_json["result"].Add(neb::CJsonObject(str));
		for(int j = 0;j<10;j++){
						std::string edge_str ="{\"sourceId\":\"";
						edge_str.append(std::to_string(i));
						edge_str.append("\",\"targetId\":\"");
						edge_str.append(std::to_string(j));
						edge_str.append("\"}");
						// std::cout<<(*nl).get_name()<<std::endl;
               			in_json["result"][i]["edge"].Add(neb::CJsonObject(edge_str));
                		// std::cout << demo_json["result"][i]["edge"].ToString() << std::endl;
            		}
					std::cout << in_json.ToString()<<std::endl;
	}
	std::cout<<in_json["result"].ToString()<<std::endl;
	char* days ;
	char* seed ;  
	strcpy(days,"30");
	strcpy(seed,"1");
	std::cout<<process(days, seed, in_json).ToFormattedString();

    // char *day = "12";
    // char *seed = "9";
    // process(day,seed,in);


}
