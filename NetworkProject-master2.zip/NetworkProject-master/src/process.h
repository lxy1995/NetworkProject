#ifndef _PROCESS_H_
#define _PROCESS_H_

#include <unistd.h>
#include <iostream>
#include <vector>
#include <ctime>
#include <igraph.h>
#include <string>
#include "runner_manager.h"
#include "runner.h"
//#incnlude "step_test.h"
#include "constant.h"
#include "parameter.h"
#include "CJsonObject.hpp" 
std::string process(const char* days ,const char* seed,const char* in_json);
#endif
	
