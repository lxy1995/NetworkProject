#include <unistd.h>
#include <iostream>
#include <vector>
#include <ctime>
#include <igraph.h>
#include <string>
#include <string.h>
#include "runner_manager.h"
#include "runner.h"
//#incnlude "step_test.h"
#include "constant.h"
#include "parameter.h"
#include "CJsonObject.hpp"
#include "process.h"
#include <stdlib.h>
#include <dlfcn.h>

int main( int argc, char* argv[] ){
	std::string strValue ="{\"responseCode\":0,\"responseMsg\":\"查询成功\"}";
    neb::CJsonObject in_json(strValue);
    in_json.AddEmptySubArray("result");
	std::cout<<in_json.ToString()<<std::endl;
	for(int i =0;i<20;i++){
		std::string id = std::to_string(i);
		std::string str = "{\"userId\":\"";
		str.append(id);
		str.append("\",\"quaranTine\": 0,\"infected\":1,\"edge\":[]}");
		in_json["result"].Add(neb::CJsonObject(str));
		for(int j = 0;j<10;j++){
						std::string edge_str ="{\"sourceId\":\"";
						edge_str.append(std::to_string(i));
						edge_str.append("\",\"targetId\":\"");
						edge_str.append(std::to_string(j));
						edge_str.append("\"}");
						// std::cout<<(*nl).get_name()<<std::endl;
               			in_json["result"][i]["edge"].Add(neb::CJsonObject(edge_str));
                		// std::cout << demo_json["result"][i]["edge"].ToString() << std::endl;
            		}
				//	std::cout << in_json.ToString()<<std::endl;
	}
	std::cout<<in_json.ToString()<<std::endl<<std::endl;
	const char* info = in_json.ToString().c_str();
	std::cout<<in_json.ToString().c_str()<<std::endl;
	std::string  exe_alg = "step_source_identification_v2";
	RunnerPtr runner = RunnerManager::instance()->get_runner(exe_alg);
	//char* days = new char[10];
	//char* seed = new char[10];  
	std::string days = "1";
	std::string seed = "14";
	//strcpy(days,"1");
	//strcpy(seed,"14");
	std::cout<<"main() is running."<<std::endl;
	std::string t = process(days.c_str(), seed.c_str(), info);
	std::cout<<t.size()<<std::endl;
 	//std::cout<<t<<std::endl;
	// Parameter para(5, para_str + 1, runner->get_short_options().c_str(), runner->get_long_options());
	// runner->run(para,in_json);
	return 0;
}
