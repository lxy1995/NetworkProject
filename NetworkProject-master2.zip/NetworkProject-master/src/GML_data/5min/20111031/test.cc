#include <stdio.h>
int main(){
	int n =1;
	printf("%d",n);
	return 0;
}