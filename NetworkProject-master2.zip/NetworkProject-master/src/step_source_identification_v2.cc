#include "step_source_identification_v2.h"
#include <stdio.h>
#include <algorithm>
#include <vector>
#include <string>
#include <memory>
#include "unistd.h" // os层面

#include "runner.h"
#include "runner_manager.h"
#include "parameter.h"
#include "undirected_graph.h"
#include "network.h"
#include "pearl_network.h"
#include "static_network.h"
#include "dynamic_network.h"
#include "simulator.h"
#include "source_identification.h"
#include "util.h"
#include "CJsonObject.hpp"

struct result_Info{
	int id {0};
	int net_size {0};
	NeighborList neightbour_node_list;
	int infected_count ;
	bool is_infected = 0;
	bool is_quaranTine = 0;
	NodeSet infected_nodes ;
	std::string  node_id {""};
	int node_degree{0};
};

bool compare(result_Info a, result_Info b )  
{  
	if(a.node_degree == b.node_degree){
		return a.id < b.id;
	}
	else return a.node_degree > b.node_degree;  
}  
StepSourceIdentificationV2 StepSourceIdentificationV2::_step_source_identification_v2;

StepSourceIdentificationV2::StepSourceIdentificationV2(): Runner() {
	_short_options = "h";
	_long_options = new struct option[100]{
		{"help",		no_argument,		NULL, OPT_HELP},
//		{"net_type",	required_argument,	NULL, OPT_NET_TYPE},
		{"net_inroot",	required_argument,	NULL, OPT_NET_INROOT},
//		{"net_injson",	required_argument,	NULL, OPT_NET_INJSON},
//		{"net_volunteers",required_argument,NULL, OPT_NET_VOLUNTEERS},
		{"out_dir",		required_argument,	NULL, OPT_OUT_DIR},
//		{"disease",		required_argument,	NULL, OPT_DISEASE},
		
//		{"infect_rate",	required_argument,	NULL, OPT_INFECT_RATE},
		{"seed_index",   required_argument,  NULL, OPT_SEED_INDEX},
//		{"infect_rate_seconds",	required_argument,	NULL, OPT_INFECT_RATE_SECONDS},

//		{"infectious_rate",	required_argument,	NULL, OPT_INFECTIOUS_RATE},
//		{"infectious_rate_seconds",	required_argument,	NULL, OPT_INFECTIOUS_RATE_SECONDS},
//		{"recover_rate",	required_argument,	NULL, OPT_RECOVER_RATE},
//		{"recover_rate_seconds",	required_argument,	NULL, OPT_RECOVER_RATE_SECONDS},
//		{"seconds_per_weight",	required_argument, NULL, OPT_SECONDS_PER_WEIGHT},
//		{"seconds_per_step",	required_argument, NULL, OPT_SECONDS_PER_STEP},
//		{"source_count",	required_argument, NULL, OPT_SOURCE_COUNT},
//		{"snapshot_coverage",	required_argument, NULL, OPT_SNAPSHOT_COVERAGE},
		{"max_sim_days",	required_argument, NULL, OPT_MAX_SIM_DAYS},
		{"repeat_times",	required_argument, NULL, OPT_REPEAT_TIMES},
//		{"source_identification_method", required_argument, NULL, OPT_SRC_IDN_METHOD},
//		{"source_identification_knowntime", required_argument, NULL, OPT_SRC_IDN_KNOWNTIME},
		{NULL,			0,					NULL,  0 } //must end with {0, 0, 0, 0}
	};
	RunnerManager::instance()->install("step_source_identification_v2", this);
	
}

void StepSourceIdentificationV2::help(){
	std::cout << "\nFunctionality: source identification. In this version, different source identification methods are compared in the exactly same simulations, thus this version is better.\n";
	std::cout << "Option list:\n";
	std::cout << "\t* --help (or -h): [ no argument ] print this help information.\n";
	// std::cout << "\t* --net_inroot: [ string argument ] root directory or file of the network(s).\n";
	std::cout << "\t* --out_dir: [ string argument ] output directory of the results.\n";
	std::cout << "\t* --disease: [ string argument ] disease model of the problem, possible values are si, sis, sir, seir.\n";
	std::cout << "\t* --infect_rate: [ double argument ] infect rate, should be in the range (0, 1).\n";
	std::cout << "\t* --seed_index: [ string argument ] seed_node should be a string \n";
	std::cout << "\t* --infect_rate_seconds: [ int/double argument ] duration of the parameter infect_rate, should be a positive value.\n";
	std::cout << "\t* --recover_rate: [ double argument ] recover rate, should be in the range (0, 1).\n";
	std::cout << "\t* --recover_rate_seconds: [ int/double argument ] duration of the parameter recover_rate, should be a positive value.\n";
	std::cout << "\t* --seconds_per_weight: [ int/double argument ] duration denoted by unit weight on the edge, should be a positive value.\n";
	std::cout << "\t* --seconds_per_step: [ int/double argument ] duration denoted by one step in the simulating process, should be a positive value.\n";
	std::cout << "\t* --max_sim_days: [ int argument ] maximal simulating duration, should be a positive value. Simulation stops once simulating time reaches this value.\n";
	std::cout << "\t* --repeat_times: [ int argument ] repeat times of simulation for every parameter setting, should be a positive value.\n";
	// std::cout << "\t* --source_identification_method: [ string argument ] method of the source identification, possible values are sse, ssebfs, tse, msep, msepbfs, urcc, sjc, jce, mjc, rg, da, ub, aub, dmp, bp, mcsm, sleuth.\n";
	// std::cout << "\t* --source_identification_knowntime: [ string argument ] denotes whether spreading time is supplied as input in the source identification problem, possible values are true, false.\n";
	std::cout << std::endl;
}


std::string StepSourceIdentificationV2::run(const Parameter& para,const neb::CJsonObject& in_json) {
	// Read network
	std::shared_ptr<Network> net = std::make_shared<StaticNetwork>(para,in_json);

	std::cout<<" static net suceed!\n"<<std::endl;
	// std::shared_ptr<Network> ntwks = std::make_shared<StaticNetwork>(para,in_json);
	std::cout <<"step SourceIdentificationV2 is running."<<std::endl;
	std::string strValue ="{\"responseCode\":0,\"responseMsg\":\"查询成功\"}";
    neb::CJsonObject info_json(strValue);
    info_json.AddEmptySubArray("result");
	
	bool is_tree = net->get_merged_graph()->is_tree();
	
	std::vector<std::string> idn_methods;
	if (is_tree) {
		idn_methods = {"sse", "ssebfs", "sjc", "jce", "rg", "da", "ub", "dmp", "mcsm", "sleuth"};
	} else {
		idn_methods = {"sse", "ssebfs", "rg", "da", "ub", "dmp", "mcsm", "sleuth"};
	}
	//idn_methods = {"dmp", "mcsm"};
	// Repeat simulation and source identification
	std::vector<SourceIdentificationResV2> res_structs(idn_methods.size());
	int repeat_times = para.get_repeat_times();
	for (int i = 0; i < idn_methods.size(); ++i) {
		res_structs[i].method_name = idn_methods[i];
		res_structs[i].running_times.resize(repeat_times);
		res_structs[i].detection_rates.resize(repeat_times);
		res_structs[i].error_distances.resize(repeat_times);
	}
	
	int n= net->get_node_size();
	// std::cout<<std::endl<<n<<std::endl;
	clock_t start_clock, end_clock;
	for (int i = 0; i < repeat_times; ++i) {
		std::cout << "Round " << i + 1 << "/" << repeat_times << std::endl;
		std::string true_seed_node;
		std::vector<DiseaseStage> sim_res;
		int infected_count ;
		NodeSet infected_node ;
		// get a simulation result which has at least 10 infected nodes.
		int contrl_times= 0;
		do {
			// Init seed
			//int true_seed_index = Util::gen_rand_int(n);
			int true_seed_index = para.get_seed_index();
			std::cout<<"get node index result:"<<true_seed_index<<std::endl;
			true_seed_node = net->get_node_name(true_seed_index);  
			// true_seed_node ="4";               // 感染源头节点ID
			std::cout<<"get node name result:"<<true_seed_node<<std::endl;

			
			contrl_times++;
			if (contrl_times > 10) break; 
			std::cout<<"LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL"<<std::endl;
			//std::cout<<"selected_seed:"<<tstd::cout<<"get node name result:"<<true_seed_node<<std::endl;rue_seed_node<<std::endl; //
			IndexSet seed_set{true_seed_index};  
			// Init simulator
			Simulator simulator(para, n, seed_set);
			// Simulate the disease spreading
			sim_res = simulator.get_sim_res(*net, para);                  // 预测感染的结果集合
			infected_count= Simulator::get_nodeset_been_infected_from_sim_res(sim_res, para.get_disease(), *net).size();          // 感染者人数预测
			
			// UndirectedGraph ug(para.get_net_inroot(),infected_node);  
			// std::cout<<std::endl<<"测试: "<<ug.get_node_size()<<std::endl;
			

			// net->get_all_contact_info();
			infected_node=Simulator::get_nodeset_been_infected_from_sim_res(sim_res, para.get_disease(), *net);
			if(infected_count < 1)  continue;
			std::cout<<std::endl;
			std::cout<<"感染人数："<<infected_count<<std::endl; //new
			std::cout<<"实际传染源id：";                             // 实际传染源头
			IndexSet::iterator is_it ;
			for(is_it=seed_set.begin();is_it!=seed_set.end();is_it++){
				printf("%d ",*is_it);
			}
			std::cout<<std::endl;
			std::cout<<"感染者节点ih："<<std::endl;					//实际感染者id统计
			std::vector<result_Info>  infected_node_info;
			NodeSet::iterator ns_it;
		
			// int parts = net->get_parts();
			// int day = net->get_days();
			// int max_day = para.get_max_sim_days();
			// int max_parts = para.get_merge_parts();
			// NeighborList nb = net->get_neighbor_list("12",0,0);


			// std::cout<<"**************** "<<nb.size()<<std::endl;
			for(ns_it=infected_node.begin();ns_it!=infected_node.end();ns_it++){
				result_Info temp;
				temp.node_id = *ns_it;
				temp.id = std::stoi(temp.node_id);
				temp.net_size = net->get_node_size();
				temp.infected_count = infected_count;
				NeighborList nb = net->get_neighbor_list(temp.node_id,0,0);
				temp.node_degree = nb.size();
				temp.is_infected = 1;
				temp.is_quaranTine = 0;
				std::cout<<"nodeID: "<<temp.node_id<<" node_degree: "<<temp.node_degree<<" net_size: "<<temp.net_size<<std::endl;
				infected_node_info.push_back(temp);
			}
			
			std::vector<result_Info>::iterator r_s;
			sort(infected_node_info.begin(),infected_node_info.end(),compare);
			int interv_count = 0.2*infected_count + 1;
			int inc = 0;
			for(r_s = infected_node_info.begin();r_s < infected_node_info.end();r_s++,inc++){
					std::cout<<"nodeID: "<<(*r_s).node_id<<" node_degree: "<<(*r_s).node_degree<<" net_size: "<<(*r_s).net_size<<std::endl;
					if(inc<interv_count){
						(*r_s).is_quaranTine = 1;
					}
					else{
						(*r_s).is_quaranTine = 0;
					}
					std::string str0 = "{\"userId\":\"";
            		std::string str1 = "{\"userId\":\"";
					str0.append((*r_s).node_id);
					str0.append("\",\"quaranTine\": 0,\"infected\":1,\"edge\":[]}");
					str1.append((*r_s).node_id);
					str1.append("\",\"quaranTine\": 1,\"infected\":1,\"edge\":[]}");
					std::cout<<"################### "<<std::endl;
            		if( (*r_s).is_quaranTine == 1){
                 		neb::CJsonObject temp(str0);
                	 	info_json["result"].Add(neb::CJsonObject(str1));
            		}
           			else info_json["result"].Add(neb::CJsonObject(str0));
					int edge_count = (*r_s).neightbour_node_list.size();
					NeighborList nb = net->get_neighbor_list((*r_s).node_id,0,0);
					NeighborList::iterator nl; 
					// std::cout<<"NNNNNNNNNNNNNNNNNNNNN\n"<<std::endl;
            		for(nl=nb.begin();nl!=nb.end();nl++){
						std::string edge_str ="{\"sourceId\":\"";
						edge_str.append((*r_s).node_id);
						edge_str.append("\",\"targetId\":\"");
						edge_str.append((*nl).get_name());
						edge_str.append("\"}");
						// std::cout<<(*nl).get_name()<<std::endl;
               			info_json["result"][i]["edge"].Add(neb::CJsonObject(edge_str));
                		// std::cout << demo_json["result"][i]["edge"].ToString() << std::endl;
            		}
					//std::cout << info_json.ToString()<<std::endl;
					std::cout << info_json.ToFormattedString()<<std::endl;
			}
			
			std::cout<<std::endl;
			std::cout<<"感染人数:"<<infected_count <<std::endl;
			std::cout<<"需要隔离者人数:"<<interv_count <<std::endl;
			
			// int inc =1;
			// for(r_s = infected_node_info.begin();inc <= interv_count ;r_s++,inc++){
			// 	std::cout<<"nodeID: "<<(*r_s).node_id<<" node_degree: "<<(*r_s).node_degree<<std::endl;
			// 	(*r_s).is_quaranTine = 1;
			// }
			
			std::cout<<std::endl;
			infected_node_info.clear();
		} while (infected_count <= 1);
		
		
		// try every possible method
		// if ( idn_methods.size()>0) {
		// 	// Infer seed and record time usage
		// 	start_clock = clock();
		// 	std::string inferred_seed_node = SourceIdentification::calc_source(*net, sim_res, para, UtilConstant::toSrcIdnMethod(idn_methods[7]), false);
		// 	end_clock = clock();
		// 	// Calculate error distance, detection rate, and running time
		// 	double error_distance = SourceIdentification::calc_error_distance(*net, true_seed_node, inferred_seed_node);
		// 	double detection_rate = SourceIdentification::calc_detection_rate(true_seed_node, inferred_seed_node);	
		// 	double running_time = 1000.0 * (end_clock - start_clock) / CLOCKS_PER_SEC;
		// 	std::cout << "Method " << idn_methods[7] << ", Time " << running_time / 1000.0 << " s." << std::endl;
		// 	std::cout<<"预测感染者id: "<<inferred_seed_node<<std::endl;    // 预测感染者
		// 	res_structs[7].running_times[i] = running_time;
		// 	res_structs[7].detection_rates[i] = detection_rate;
		// 	res_structs[7].error_distances[i] = error_distance;
		// 	std::cout<<"错误距离："<<error_distance <<std::endl;
		// }
			std::cout<<std::endl; 
	}
	// Calculate error distance, detection rate, running time.
	
	// if(idn_methods.size()>0) {
	// 	res_structs[7].running_time_mean = Util::getMean(res_structs[7].running_times);
	// 	res_structs[7].running_time_sigma = Util::getDeviation(res_structs[7].running_times, res_structs[7].running_time_mean);
	// 	res_structs[7].detection_rate = Util::getMean(res_structs[7].detection_rates);
	// 	res_structs[7].error_distance_mean = Util::getMean(res_structs[7].error_distances);
	// 	res_structs[7].error_distance_sigma = Util::getDeviation(res_structs[7].error_distances, res_structs[7].error_distance_mean);
	// }

	// Write results to files.
	// write_result(para.get_out_dir(), res_structs);
	std::string result = info_json.ToFormattedString();
	return  result;

}


void StepSourceIdentificationV2::write_result(const std::string& res_dir, const std::vector<SourceIdentificationResV2>& res_structs) {
	std::string details_dir = res_dir + "/details/", summary = res_dir + "/summary.txt";
	std::string mkdir_command = "mkdir -p " + details_dir;
	int sys_val = system(mkdir_command.c_str());
	// write details
	for (int j = 0; j < res_structs.size(); ++j) {
		std::string details = details_dir + res_structs[j].method_name + ".txt";
		std::ofstream ofs(details.c_str());
		if (ofs.fail()) {
			std::cerr << "Error writing file: " << details << std::endl;
			exit(-1);
		}
		ofs << "#index detection_rate error_distance running_time(ms)" << std::endl;
		for (int i = 0; i < res_structs[j].error_distances.size(); ++i) {
			ofs << i + 1 << " " << res_structs[j].detection_rates[i] << " " << res_structs[j].error_distances[i] << " " << res_structs[j].running_times[i] << std::endl;
		}
		ofs.close();
	}

	// write summary
	std::ofstream ofs(summary.c_str());
	if (ofs.fail()) {
		std::cerr << "Error writing file: " << summary << std::endl;
		exit(-1);
	}
	ofs << "#Method detection_rate error_distance_mean error_distance_sigma running_time_mean running_time_sigma" << std::endl;
	for (int i = 0; i < res_structs.size(); ++i) {
		ofs << res_structs[i].method_name << " ";
		ofs << res_structs[i].detection_rate << " ";
		ofs << res_structs[i].error_distance_mean << " ";
		ofs << res_structs[i].error_distance_sigma << " ";
		ofs << res_structs[i].running_time_mean << " ";
		ofs << res_structs[i].running_time_sigma << std::endl;
	}
	ofs.close();
}

// std::string userId:"62",


//  {
//   "responseCode": 0,
//   "responseMsg": "查询成功",

//   "result": [
//     {
//       "userId": "628497914d4a4ee18e623ac3dc90514e",
//       "quaranTine": 0,
//       "infected": 0,
//       "edge": [
//         {
//           "sourceId": "628497914d4a4ee18e623ac3dc90514e",
//           "targetId": "671e75c08d4747958b73dc38643ea35a"
//         },
//         {
//           "sourceId": "628497914d4a4ee18e623ac3dc90514e",
//           "targetId": "9c4f7405044e488e9d5cc0feb1d6ab37"
//         }
//       ]
//     },
//     {
//       "userId": "135e8fab790648c3a4a8f99d417dbe76",
//       "quaranTine": 0,
//       "infected": 0,
//       "edge": [
//         {
//           "sourceId": "135e8fab790648c3a4a8f99d417dbe76",
//           "targetId": "6fd78c5d5873469394940b2debca3e9c"
//         },
//         {
//           "sourceId": "135e8fab790648c3a4a8f99d417dbe76",
//           "targetId": "8114ce14148244cba2a5756576568c9d"
//         }
//       ]
//     }
//   ]
// }