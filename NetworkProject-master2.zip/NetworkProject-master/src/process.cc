#include <unistd.h>
#include <iostream>
#include <stdlib.h>
#include <vector>
#include <ctime>
#include <igraph.h>
#include <string>
#include <string.h>
#include "runner_manager.h"
#include "runner.h"
// #incnlude "step_test.h"
#include "constant.h"
#include "parameter.h"
#include "CJsonObject.hpp"
#include "process.h"

// extern "C" std::string process(const char* days,const char* seed,const char* in_json);

std::string process(const char* days ,const  char* seed,const char*  in_json){
	if((days ==NULL )|| (seed == NULL) || (in_json == NULL)){
		throw "arguments is not eno";
	} 
	igraph_i_set_attribute_table(&igraph_cattribute_table);
	srand(time(NULL));
	neb::CJsonObject info(in_json);
	std::string  exe_alg = "step_source_identification_v2";
	RunnerPtr runner = RunnerManager::instance()->get_runner(exe_alg);
   	char p1[] ="netjob";
	char p2[] ="step_source_identification_v2";
	char p3[] ="--seed_index";
	char p4[5] ="4";
	char p5[] ="--max_sim_days";
	char p6[5] ="10";
	strcpy(p4,seed);
	strcpy(p6,days);
	char * para_str[6] = {p1,p2,p3,p4,p5,p6};
	Parameter para(5, para_str + 1, runner->get_short_options().c_str(), runner->get_long_options());
	std::string str("");
	neb::CJsonObject result = runner->run(para,info);
	if(result.IsEmpty()) throw "the problems of info";
	// std::string  str = "I love this project";
	str = result.ToString();
	return str;
}
